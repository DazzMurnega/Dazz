﻿using Microsoft.AspNetCore.Mvc;
using SSWeb.Models;
using System.Text;



namespace SSWeb.Controllers
{
    public class UserController : Controller
    {

        /// <summary>
        /// public IActionResult Index()
        /// </summary>
        /// <returns></returns>
        //{
        //    UserInfo u = new UserInfo();
        //    var data = u;
        //    return View();
        //}

        //public async Task<IActionResult> SetUserSession(String Uname) { 
        //    return View();
        //}
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        public ActionResult verify(UserInfo user)
        {
            return View();
        }
        
        public async Task<ActionResult> Login( UserInfo u)
        {
          

            if (!ModelState.IsValid)
            {
               
                return View(u);
            }
            Console.WriteLine(u.UserName.ToString());
            Console.WriteLine(u.UserPassword.ToString());
            
            UserInfo login = new UserInfo();
            login.UserName= u.UserName;
            login.UserPassword= u.UserPassword;
            HttpClient client = new HttpClient();

            

            // client.BaseAddress= new Uri("https://localhost:7084/api/UserInfo");
            string baseurl = "https://localhost:7084/api/UserInfo";
            // client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue ("application/json"));
            string content = System.Text.Json.JsonSerializer.Serialize(u);
            var content2 = new StringContent(content, Encoding.UTF8, "application/json");
            HttpResponseMessage r2 = await client.GetAsync($"/api/login/itemsCategory?uName={login.UserName}");
            HttpResponseMessage response = await client.GetAsync(baseurl);
           
            if(r2.IsSuccessStatusCode)
            {
                if (response.IsSuccessStatusCode)
                {





                    return RedirectToAction("Index.cshtml");
                }
            }
            
            
           
            
            
                
                return View(u);
            
            

        }
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create([Bind("UserName,UserSurname,UserContactNo,UserPassword")]UserInfo u)
        {
            if (!ModelState.IsValid)
            {
                return View(u);
            }
            Console.WriteLine(u.UserName.ToString());
            Console.WriteLine(u.UserPassword.ToString());
            
            Console.WriteLine(u.UserSurname.ToString());
            Console.WriteLine(u.UserContactNo.ToString());
            u.UserDeleted = false;
            u.UserRegDate = DateTime.Now;
            u.UserTypeId = 3;

            HttpClient client = new HttpClient();

            // client.BaseAddress= new Uri("https://localhost:7084/api/UserInfo");
            string baseurl = "https://localhost:7084/api/UserInfo";
            // client.DefaultRequestHeaders.Accept.Clear();
            //client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue ("application/json"));
            string content = System.Text.Json.JsonSerializer.Serialize(u);
            var content2 = new StringContent(content,Encoding.UTF8,"application/json");
            HttpResponseMessage response = await client.PostAsync(baseurl,content2);

            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Login");
            }
            return View(u);
            
        }
    }
}
