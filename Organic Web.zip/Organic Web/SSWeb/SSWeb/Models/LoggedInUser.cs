﻿namespace SSWeb.Models
{
    [Serializable]
    public class LoggedInUser
    {
        public long Id { get; set; }
        public string AccType { get; set; }
    }
}
