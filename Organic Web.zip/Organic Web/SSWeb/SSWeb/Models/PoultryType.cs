﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class PoultryType
{
    public int PoultryTypeId { get; set; }

    public string PoultryTypeName { get; set; } = null!;

}
