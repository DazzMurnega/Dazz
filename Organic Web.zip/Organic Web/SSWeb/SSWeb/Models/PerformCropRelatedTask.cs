﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class PerformCropRelatedTask
{
    public int CropId { get; set; }

    public int TaskId { get; set; }

    public int? CropPlantationId { get; set; }

    public int? CropHarvestId { get; set; }
}
