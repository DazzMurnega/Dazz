﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Broiler
{
    public int AnimalId { get; set; }

    public DateTime BroilerReceivedDate { get; set; }

    public decimal BroilerAverageWeight { get; set; }

    public DateTime? BroilerSoldDate { get; set; }
}
