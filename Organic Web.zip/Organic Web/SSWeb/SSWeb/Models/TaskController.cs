﻿//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using Organic_Farm_Web_API.Models;
//using Task = Organic_Farm_Web_API.Models.Task;

//namespace Organic_Farm_Web_API.Controllers
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class TaskController : ControllerBase
//    {
//        private readonly DataContext _farmContext;

//        public TaskController(FarmDbContext context)
//        {
//            _farmContext = context;
//        }

//        //Methods for Task Category
//        [HttpPost]
//        [Route("addTaskCategory")]
//        public async Task<ActionResult<TaskCategory>> addTaskCategory(TaskCategory cat)
//        {
//            _farmContext.TaskCategories.Add(cat);
//            await _farmContext.SaveChangesAsync();
//            return Ok("Task category has been added.");
//        }

//        [HttpGet]
//        [Route("getTaskCategories")]
//        public async Task<ActionResult<TaskCategory>> getTaskCategories()
//        {
//            if (_farmContext.TaskCategories.Count() == 0)
//            {
//                return NotFound("No task category has been added");
//            }
//            else
//            {
//                return Ok(await _farmContext.TaskCategories.ToListAsync());
//            }
//        }

//        [HttpGet("/getTaskCategory/{id}")]
//        public async Task<ActionResult<TaskCategory>> getTaskCategoryById(int id)
//        {
//            var cat = await _farmContext.TaskCategories.FindAsync(id);
//            if (cat == null)
//            {
//                return NotFound("Task category " + id + " is not found.");
//            }
//            else
//            {
//                return Ok(cat);
//            }
//        }

//        [HttpPut]
//        [Route("updateTaskCategory")]
//        public async Task<ActionResult<TaskCategory>> updateTaskCategory(TaskCategory cat)
//        {
//            _farmContext.TaskCategories.Update(cat);
//            await _farmContext.SaveChangesAsync();

//            return Ok("Task category has been updated");
//        }

//        [HttpDelete("/deleteTaskCategory/{id}")]
//        public async Task<ActionResult<TaskCategory>> deleteTaskCategory(int id)
//        {
//            var cat = _farmContext.TaskCategories.Find(id);
//            if (cat == null)
//            {
//                return NotFound("Task category " + id + " is not found");
//            }
//            else
//            {
//                _farmContext.TaskCategories.Remove(cat);
//                await _farmContext.SaveChangesAsync();

//                return Ok("Task category has been removed");
//            }
//        }

//        //Methods for Task
//        [HttpPost]
//        [Route("addTask")]
//        public async Task<ActionResult<Task>> addTask(Task task)
//        {
//            _farmContext.Tasks.Add(task);
//            await _farmContext.SaveChangesAsync();
//            return Ok("Task has been added.");
//        }

//        [HttpGet]
//        [Route("getTasks")]
//        public async Task<ActionResult<Task>> getTasks()
//        {
//            if (_farmContext.Tasks.Count() == 0)
//            {
//                return NotFound("No task has been added");
//            }
//            else
//            {
//                return Ok(await _farmContext.Tasks.ToListAsync());
//            }
//        }

//        [HttpGet("/getTask/{id}")]
//        public async Task<ActionResult<Task>> getTaskById(int id)
//        {
//            var task = await _farmContext.Tasks.FindAsync(id);
//            if (task == null)
//            {
//                return NotFound("Task " + id + " is not found.");
//            }
//            else
//            {
//                return Ok(task);
//            }
//        }

//        [HttpPut]
//        [Route("updateTask")]
//        public async Task<ActionResult<Task>> updateTask(Task task)
//        {
//            _farmContext.Tasks.Update(task);
//            await _farmContext.SaveChangesAsync();

//            return Ok("Task has been updated");
//        }

//        [HttpDelete("/deleteTask/{id}")]
//        public async Task<ActionResult<Task>> deleteTask(int id)
//        {
//            var task = _farmContext.Tasks.Find(id);
//            if (task == null)
//            {
//                return NotFound("Task " + id + " is not found");
//            }
//            else
//            {
//                _farmContext.Tasks.Remove(task);
//                await _farmContext.SaveChangesAsync();

//                return Ok("Task has been removed");
//            }
//        }

//        //Methods for Task rating
//        [HttpPost]
//        [Route("addTaskRating")]
//        public async Task<ActionResult<TaskRating>> addTaskRating(TaskRating rating, int TaskId, int UserId)
//        {
//            _farmContext.TaskRatings.Add(rating);
//            await _farmContext.SaveChangesAsync();

//            var task = _farmContext.AllocateTasks.Find(TaskId, UserId);
//            if (task != null)
//            {
//                task.TaskRatingId = rating.TaskRatingId;
//                await _farmContext.SaveChangesAsync();
//            }

//            return Ok("Task rating has been added.");
//        }

//        [HttpGet]
//        [Route("getTaskRatings")]
//        public async Task<ActionResult<TaskRating>> getTaskRatings()
//        {
//            if (_farmContext.TaskRatings.Count() == 0)
//            {
//                return NotFound("No task ratings has been added");
//            }
//            else
//            {
//                return Ok(await _farmContext.TaskRatings.ToListAsync());
//            }
//        }

//        [HttpGet("/getTaskRating/{id}")]
//        public async Task<ActionResult<TaskRating>> getTaskRatingById(int id)
//        {
//            var rating = await _farmContext.TaskRatings.FindAsync(id);
//            if (rating == null)
//            {
//                return NotFound("Task rating " + id + " is not found.");
//            }
//            else
//            {
//                return Ok(rating);
//            }
//        }

//        [HttpPut]
//        [Route("updateTaskRating")]
//        public async Task<ActionResult<TaskRating>> updateTaskRating(TaskRating rating)
//        {
//            _farmContext.TaskRatings.Update(rating);
//            await _farmContext.SaveChangesAsync();

//            return Ok("Task rating has been updated");
//        }

//        [HttpDelete("/deleteTaskRating/{TaskId}/{UserId}/{ratingId}")]
//        public async Task<ActionResult<TaskRating>> deleteTaskRating(int TaskId, int UserId, int ratingId)
//        {
//            var rating = _farmContext.TaskRatings.Find(ratingId);
//            if (rating == null)
//            {
//                return NotFound("Task rating " + ratingId + " is not found");
//            }
//            else
//            {
//                var task = _farmContext.AllocateTasks.Find(TaskId, UserId);
//                if (task != null)
//                {
//                    task.TaskRatingId = null;
//                    await _farmContext.SaveChangesAsync();
//                }

//                _farmContext.TaskRatings.Remove(rating);
//                await _farmContext.SaveChangesAsync();

//                return Ok("Task rating has been removed");
//            }
//        }

//        //Methods for Allocate Task
//        [HttpPost]
//        [Route("addAllocateTask")]
//        public async Task<ActionResult<AllocateTask>> addAllocateTask(AllocateTask at)
//        {
//            _farmContext.AllocateTasks.Add(at);
//            await _farmContext.SaveChangesAsync();
//            return Ok("Task allocation has been added.");
//        }

//        [HttpGet]
//        [Route("getAllocateTasks")]
//        public async Task<ActionResult<AllocateTask>> getAllocateTasks()
//        {
//            if (_farmContext.AllocateTasks.Count() == 0)
//            {
//                return NotFound("No task has been allocated");
//            }
//            else
//            {
//                return Ok(await _farmContext.AllocateTasks.ToListAsync());
//            }
//        }

//        [HttpGet("/getAllocateTask/{UserId}/{TaskId}")]
//        public async Task<ActionResult<AllocateTask>> getAllocateTaskById(int UserId, int TaskId)
//        {
//            var at = await _farmContext.AllocateTasks.FindAsync(UserId, TaskId);
//            if (at == null)
//            {
//                return NotFound("Task allocation (" + UserId + ", " + TaskId + " is not found.");
//            }
//            else
//            {
//                return Ok(at);
//            }
//        }

//        [HttpPut]
//        [Route("updateAllocateTask")]
//        public async Task<ActionResult<AllocateTask>> updateAllocateTask(AllocateTask at)
//        {
//            _farmContext.AllocateTasks.Update(at);
//            await _farmContext.SaveChangesAsync();

//            return Ok("Task allocation has been updated");
//        }

//        [HttpDelete("/deleteAllocateTask/{UserId}/{TaskId}")]
//        public async Task<ActionResult<AllocateTask>> deleteAllocateTask(int UserId, int TaskId)
//        {
//            var at = _farmContext.AllocateTasks.Find(UserId, TaskId);
//            if (at == null)
//            {
//                return NotFound("Task allocation (" + UserId + ", " + TaskId + ") is not found");
//            }
//            else
//            {
//                _farmContext.AllocateTasks.Remove(at);
//                await _farmContext.SaveChangesAsync();

//                return Ok("Task allocation has been removed");
//            }
//        }
//    }
//}
