﻿namespace SSWeb.Models
{
    public class Login
    {
        public string Username { get; set; } = null!;
        public string UserPassword { get; set; } = null!;
    }
}
