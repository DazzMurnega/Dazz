﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Layer
{
    public int AnimalId { get; set; }

    public int? LayerEggsProduced { get; set; }

    public int AveEggSizeId { get; set; }
}
