﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class AnimalFeedType
{
    public int AnimalFeedTypeId { get; set; }

    public string AnimalFeedTypeName { get; set; } = null!;
}
