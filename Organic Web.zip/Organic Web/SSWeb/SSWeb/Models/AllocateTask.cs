﻿//using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class AllocateTask
{
//    public required int AllocateTaskId { get; set; }

//    public int UserId { get; set; }

//    public DateTime TaskCompletionDate { get; set; }

//    public string? TaskFeedback { get; set; }

//    public int? TaskRatingId { get; set; }
}
