﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Poultry
{
    public int AnimalId { get; set; }

    public int PoultryTypeId { get; set; }

    public int ChickenCoupId { get; set; }

}
