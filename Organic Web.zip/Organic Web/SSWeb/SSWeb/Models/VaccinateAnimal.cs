﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class VaccinateAnimal
{
    public int AnimalVaccinationId { get; set; }

    public string AnimalVaccinationName { get; set; } = null!;

    public DateTime AnimalVaccinationReceivedDate { get; set; }

    public decimal AnimalVaccinationDosage { get; set; }
}
