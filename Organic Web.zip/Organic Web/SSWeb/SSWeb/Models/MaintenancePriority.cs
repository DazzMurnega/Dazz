﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class MaintenancePriority
{
    public int MaintenancePriorityId { get; set; }

    public string? MaintenancePriorityName { get; set; }
}
