﻿using System.ComponentModel.DataAnnotations;
using System.Xml.Linq;

namespace SSWeb.Models
{
    public class UserInfo
    {
        public int UserInfoId { get; set; }

        public string UserName { get; set; } = null!;

        public string UserSurname { get; set; } = null!;

        public string UserContactNo { get; set; } = null!;

        public string UserPassword { get; set; } = null!;

        public DateTime UserRegDate { get; set; }

        public bool UserDeleted { get; set; }

        public int UserTypeId { get; set; }
    }
}
