﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class ChickenCoup
{
    public int ChickenCoupId { get; set; }

    public decimal ChickenCoupPreffTemp { get; set; }

    public decimal ChickenCoupPreffHumidity { get; set; }
}
