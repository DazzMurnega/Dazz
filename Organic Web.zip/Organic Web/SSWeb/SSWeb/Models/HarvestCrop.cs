﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class HarvestCrop
{
    public int CropHarvestId { get; set; }

    public int HarvestSeasonId { get; set; }

    public DateTime CropHarevstDate { get; set; }

    public int? HarvestQualityId { get; set; }

    public decimal? HarvestSales { get; set; }
}
