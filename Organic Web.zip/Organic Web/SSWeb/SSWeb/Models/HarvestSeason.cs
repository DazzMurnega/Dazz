﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class HarvestSeason
{
    public int HarvestSeasonId { get; set; }

    public string HarvestSeasonDescription { get; set; } = null!;
}
