﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class RecordMaintenanceIssue
{
    public int UserId { get; set; }

    public int MaintenanceId { get; set; }

    public int? MaintenanceSolutionId { get; set; }

    public string? MaintenanceIssueDescription { get; set; }

    public DateTime? MaintenanceIssueRecordingDate { get; set; }

}
