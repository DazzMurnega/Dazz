﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Maintenance
{
    public int MaintenanceId { get; set; }

    public int MaintenancePriorityId { get; set; }
}
