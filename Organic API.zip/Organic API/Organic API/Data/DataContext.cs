﻿using Microsoft.EntityFrameworkCore;
using Organic_API.Entities;
using Organic_Farm_Web_API.Models;

namespace Organic_API.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {

        }

        public DbSet<UserInfo> Users { get; set; }
       // public DbSet<AllocateTask> AllocateTasks { get; set; }

        public DbSet<Animal> Animals { get; set; }

        public DbSet<AnimalFeedType> AnimalFeedTypes { get; set; }

        public DbSet<AnimalType> AnimalTypes { get; set; }

        public DbSet<AveEggSize> AveEggSizes { get; set; }

        public DbSet<Broiler> Broilers { get; set; }

        public DbSet<ChickenCoup> ChickenCoups { get; set; }

        public DbSet<Crop> Crops { get; set; }

        public DbSet<CropType> CropTypes { get; set; }

        public DbSet<FeedAnimal> FeedAnimals { get; set; }

        public DbSet<HarvestCrop> HarvestCrops { get; set; }

        public DbSet<HarvestQuality> HarvestQualities { get; set; }

        public DbSet<HarvestSeason> HarvestSeasons { get; set; }

        public DbSet<Layer> Layers { get; set; }

        public DbSet<Maintenance> Maintenances { get; set; }

        public DbSet<MaintenancePriority> MaintenancePriorities { get; set; }

        public DbSet<MaintenanceSolution> MaintenanceSolutions { get; set; }

        public DbSet<PerformAnimalRelatedTask> PerformAnimalRelatedTasks { get; set; }

        public DbSet<PerformCropRelatedTask> PerformCropRelatedTasks { get; set; }

        public DbSet<PlantCrop> PlantCrops { get; set; }

        public DbSet<Poultry> Poultries { get; set; }

        public DbSet<PoultryType> PoultryTypes { get; set; }

        public DbSet<RecordMaintenanceIssue> RecordMaintenanceIssues { get; set; }

        public DbSet<Organic_Farm_Web_API.Models.Task> Tasks { get; set; }

        public DbSet<TaskCategory> TaskCategories { get; set; }

        public DbSet<TaskRating> TaskRatings { get; set; }

       

        public DbSet<UserType> UserTypes { get; set; }

        public DbSet<VaccinateAnimal> VaccinateAnimals { get; set; }
    }
}
