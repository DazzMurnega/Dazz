﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class PlantCrop
{
    public int PlantCropId { get; set; }

    public DateTime CropPlantationDate { get; set; }
}
