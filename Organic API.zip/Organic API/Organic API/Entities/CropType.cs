﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class CropType
{
    public int CropTypeId { get; set; }

    public string? CropTypeName { get; set; }
}
