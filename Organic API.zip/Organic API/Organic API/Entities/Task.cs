﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Task
{
    public int TaskId { get; set; }

    public string TaskDescription { get; set; } = null!;

    public DateTime TaskStartDate { get; set; }

    public DateTime TaskEndDate { get; set; }

    public int TaskCategoryId { get; set; }
}
