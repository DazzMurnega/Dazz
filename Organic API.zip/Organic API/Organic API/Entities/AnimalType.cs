﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class AnimalType
{
    public int AnimalTypeId { get; set; }

    public string AnimalTypeName { get; set; } = null!;
}
