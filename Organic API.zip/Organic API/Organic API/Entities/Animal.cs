﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Animal
{
    public int AnimalId { get; set; }

    public int AnimalTypeId { get; set; }

    public int? AnimalCount { get; set; }
}
