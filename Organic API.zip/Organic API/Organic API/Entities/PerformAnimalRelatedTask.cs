﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class PerformAnimalRelatedTask
{
   
    public required int PerformAnimalRelatedTaskId { get; set; }
    
    public int AnimalId { get; set; }

    public int TaskId { get; set; }

    public int? AnimalVaccinationId { get; set; }

    public int? AnimalFeedId { get; set; }
}
