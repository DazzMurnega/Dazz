﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Broiler
{
   public required int BroilerId { get; set; }

    public int AnimalId { get; set; }

    public DateTime BroilerReceivedDate { get; set; } 

    public decimal BroilerAverageWeight { get; set; }

    public DateTime? BroilerSoldDate { get; set; }
}
