﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class Crop
{
    public int CropId { get; set; }

    public int CropTypeId { get; set; }

    public decimal CropPrice { get; set; }

    public virtual CropType CropType { get; set; } = null!;
}