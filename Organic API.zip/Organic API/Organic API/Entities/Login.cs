﻿namespace Organic_API.Entities
{
    public class Login
    {
        public string UserName { get; set; } = null!;
        public string UserPassword { get; set; } = null!;
    }
}
