﻿namespace Organic_API.Entities
{
    public class UserInfo
    {
        public required int UserInfoId { get; set; }

        public string UserName { get; set; } = null!;

        public string UserSurname { get; set; } = null!;

        public string UserContactNo { get; set; } = null!;

        public string UserPassword { get; set; } = null!;

        public DateTime UserRegDate { get; set; }

        public bool UserDeleted { get; set; }

        public int UserTypeId { get; set; }
    }
}
