﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;

namespace Organic_API.Entities;

public partial class AllocateTask
{
    public required int AtId { get; set; }
    
    public  int TaskId { get; set; }

     public int UserInfoId { get; set; }

    public DateTime TaskCompletionDate { get; set; }

    public string? TaskFeedback { get; set; }

    public int? TaskRatingId { get; set; }
}
