﻿using System;
using System.Collections.Generic;

namespace Organic_Farm_Web_API.Models;

public partial class FeedAnimal
{
   

    public required int FeedAnimalId { get; set; }

    public int AnimalFeedTypeId { get; set; }

    public decimal AnimalFeedQuantity { get; set; }

    public virtual AnimalFeedType AnimalFeedType { get; set; } = null!;
}
