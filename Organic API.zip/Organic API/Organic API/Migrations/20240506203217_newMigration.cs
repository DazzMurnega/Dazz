﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Organic_API.Migrations
{
    /// <inheritdoc />
    public partial class newMigration : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Id",
                table: "Users",
                newName: "UserInfoId");

            migrationBuilder.CreateTable(
                name: "AnimalFeedTypes",
                columns: table => new
                {
                    AnimalFeedTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalFeedTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AnimalFeedTypes", x => x.AnimalFeedTypeId);
                });

            migrationBuilder.CreateTable(
                name: "Animals",
                columns: table => new
                {
                    AnimalId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalTypeId = table.Column<int>(type: "int", nullable: false),
                    AnimalCount = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Animals", x => x.AnimalId);
                });

            migrationBuilder.CreateTable(
                name: "AnimalTypes",
                columns: table => new
                {
                    AnimalTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AnimalTypes", x => x.AnimalTypeId);
                });

            migrationBuilder.CreateTable(
                name: "AveEggSizes",
                columns: table => new
                {
                    AveEggSizeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AveEggSizeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AveEggSizes", x => x.AveEggSizeId);
                });

            migrationBuilder.CreateTable(
                name: "Broilers",
                columns: table => new
                {
                    BroilerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalId = table.Column<int>(type: "int", nullable: false),
                    BroilerReceivedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    BroilerAverageWeight = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    BroilerSoldDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Broilers", x => x.BroilerId);
                });

            migrationBuilder.CreateTable(
                name: "ChickenCoups",
                columns: table => new
                {
                    ChickenCoupId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ChickenCoupPreffTemp = table.Column<decimal>(type: "decimal(18,2)", nullable: false),
                    ChickenCoupPreffHumidity = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ChickenCoups", x => x.ChickenCoupId);
                });

            migrationBuilder.CreateTable(
                name: "CropTypes",
                columns: table => new
                {
                    CropTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CropTypeName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CropTypes", x => x.CropTypeId);
                });

            migrationBuilder.CreateTable(
                name: "HarvestCrops",
                columns: table => new
                {
                    HarvestCropId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HarvestSeasonId = table.Column<int>(type: "int", nullable: false),
                    CropHarevstDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    HarvestQualityId = table.Column<int>(type: "int", nullable: true),
                    HarvestSales = table.Column<decimal>(type: "decimal(18,2)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HarvestCrops", x => x.HarvestCropId);
                });

            migrationBuilder.CreateTable(
                name: "HarvestQualities",
                columns: table => new
                {
                    HarvestQualityId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HarvestQualityName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HarvestQualities", x => x.HarvestQualityId);
                });

            migrationBuilder.CreateTable(
                name: "HarvestSeasons",
                columns: table => new
                {
                    HarvestSeasonId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    HarvestSeasonDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_HarvestSeasons", x => x.HarvestSeasonId);
                });

            migrationBuilder.CreateTable(
                name: "Layers",
                columns: table => new
                {
                    LayerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalId = table.Column<int>(type: "int", nullable: false),
                    LayerEggsProduced = table.Column<int>(type: "int", nullable: true),
                    AveEggSizeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Layers", x => x.LayerId);
                });

            migrationBuilder.CreateTable(
                name: "MaintenancePriorities",
                columns: table => new
                {
                    MaintenancePriorityId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaintenancePriorityName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaintenancePriorities", x => x.MaintenancePriorityId);
                });

            migrationBuilder.CreateTable(
                name: "Maintenances",
                columns: table => new
                {
                    MaintenanceId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaintenancePriorityId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Maintenances", x => x.MaintenanceId);
                });

            migrationBuilder.CreateTable(
                name: "MaintenanceSolutions",
                columns: table => new
                {
                    MaintenanceSolutionId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    MaintenanceSolutionDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    MaintenanceSolutionFeedback = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MaintenanceSolutions", x => x.MaintenanceSolutionId);
                });

            migrationBuilder.CreateTable(
                name: "PerformAnimalRelatedTasks",
                columns: table => new
                {
                    PerformAnimalRelatedTaskId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalId = table.Column<int>(type: "int", nullable: false),
                    TaskId = table.Column<int>(type: "int", nullable: false),
                    AnimalVaccinationId = table.Column<int>(type: "int", nullable: true),
                    AnimalFeedId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PerformAnimalRelatedTasks", x => x.PerformAnimalRelatedTaskId);
                });

            migrationBuilder.CreateTable(
                name: "PerformCropRelatedTasks",
                columns: table => new
                {
                    PerformCropRelatedTaskId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CropId = table.Column<int>(type: "int", nullable: false),
                    TaskId = table.Column<int>(type: "int", nullable: false),
                    CropPlantationId = table.Column<int>(type: "int", nullable: true),
                    CropHarvestId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PerformCropRelatedTasks", x => x.PerformCropRelatedTaskId);
                });

            migrationBuilder.CreateTable(
                name: "PlantCrops",
                columns: table => new
                {
                    PlantCropId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CropPlantationDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PlantCrops", x => x.PlantCropId);
                });

            migrationBuilder.CreateTable(
                name: "Poultries",
                columns: table => new
                {
                    PoultryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalId = table.Column<int>(type: "int", nullable: false),
                    PoultryTypeId = table.Column<int>(type: "int", nullable: false),
                    ChickenCoupId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Poultries", x => x.PoultryId);
                });

            migrationBuilder.CreateTable(
                name: "PoultryTypes",
                columns: table => new
                {
                    PoultryTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    PoultryTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PoultryTypes", x => x.PoultryTypeId);
                });

            migrationBuilder.CreateTable(
                name: "RecordMaintenanceIssues",
                columns: table => new
                {
                    RecordMaintenanceIssueId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserInfoId = table.Column<int>(type: "int", nullable: false),
                    MaintenanceId = table.Column<int>(type: "int", nullable: false),
                    MaintenanceSolutionId = table.Column<int>(type: "int", nullable: true),
                    MaintenanceIssueDescription = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    MaintenanceIssueRecordingDate = table.Column<DateTime>(type: "datetime2", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RecordMaintenanceIssues", x => x.RecordMaintenanceIssueId);
                });

            migrationBuilder.CreateTable(
                name: "TaskCategories",
                columns: table => new
                {
                    TaskCategoryId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TaskCategoryName = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TaskCategories", x => x.TaskCategoryId);
                });

            migrationBuilder.CreateTable(
                name: "TaskRatings",
                columns: table => new
                {
                    TaskRatingId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TaskRatingLevel = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TaskRatings", x => x.TaskRatingId);
                });

            migrationBuilder.CreateTable(
                name: "Tasks",
                columns: table => new
                {
                    TaskId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TaskDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TaskStartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TaskEndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    TaskCategoryId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tasks", x => x.TaskId);
                });

            migrationBuilder.CreateTable(
                name: "UserTypes",
                columns: table => new
                {
                    UserTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserTypeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserTypes", x => x.UserTypeId);
                });

            migrationBuilder.CreateTable(
                name: "VaccinateAnimals",
                columns: table => new
                {
                    VaccinateAnimalId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalVaccinationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    AnimalVaccinationReceivedDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AnimalVaccinationDosage = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VaccinateAnimals", x => x.VaccinateAnimalId);
                });

            migrationBuilder.CreateTable(
                name: "FeedAnimals",
                columns: table => new
                {
                    FeedAnimalId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AnimalFeedTypeId = table.Column<int>(type: "int", nullable: false),
                    AnimalFeedQuantity = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FeedAnimals", x => x.FeedAnimalId);
                    table.ForeignKey(
                        name: "FK_FeedAnimals_AnimalFeedTypes_AnimalFeedTypeId",
                        column: x => x.AnimalFeedTypeId,
                        principalTable: "AnimalFeedTypes",
                        principalColumn: "AnimalFeedTypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Crops",
                columns: table => new
                {
                    CropId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CropTypeId = table.Column<int>(type: "int", nullable: false),
                    CropPrice = table.Column<decimal>(type: "decimal(18,2)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Crops", x => x.CropId);
                    table.ForeignKey(
                        name: "FK_Crops_CropTypes_CropTypeId",
                        column: x => x.CropTypeId,
                        principalTable: "CropTypes",
                        principalColumn: "CropTypeId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Crops_CropTypeId",
                table: "Crops",
                column: "CropTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_FeedAnimals_AnimalFeedTypeId",
                table: "FeedAnimals",
                column: "AnimalFeedTypeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Animals");

            migrationBuilder.DropTable(
                name: "AnimalTypes");

            migrationBuilder.DropTable(
                name: "AveEggSizes");

            migrationBuilder.DropTable(
                name: "Broilers");

            migrationBuilder.DropTable(
                name: "ChickenCoups");

            migrationBuilder.DropTable(
                name: "Crops");

            migrationBuilder.DropTable(
                name: "FeedAnimals");

            migrationBuilder.DropTable(
                name: "HarvestCrops");

            migrationBuilder.DropTable(
                name: "HarvestQualities");

            migrationBuilder.DropTable(
                name: "HarvestSeasons");

            migrationBuilder.DropTable(
                name: "Layers");

            migrationBuilder.DropTable(
                name: "MaintenancePriorities");

            migrationBuilder.DropTable(
                name: "Maintenances");

            migrationBuilder.DropTable(
                name: "MaintenanceSolutions");

            migrationBuilder.DropTable(
                name: "PerformAnimalRelatedTasks");

            migrationBuilder.DropTable(
                name: "PerformCropRelatedTasks");

            migrationBuilder.DropTable(
                name: "PlantCrops");

            migrationBuilder.DropTable(
                name: "Poultries");

            migrationBuilder.DropTable(
                name: "PoultryTypes");

            migrationBuilder.DropTable(
                name: "RecordMaintenanceIssues");

            migrationBuilder.DropTable(
                name: "TaskCategories");

            migrationBuilder.DropTable(
                name: "TaskRatings");

            migrationBuilder.DropTable(
                name: "Tasks");

            migrationBuilder.DropTable(
                name: "UserTypes");

            migrationBuilder.DropTable(
                name: "VaccinateAnimals");

            migrationBuilder.DropTable(
                name: "CropTypes");

            migrationBuilder.DropTable(
                name: "AnimalFeedTypes");

            migrationBuilder.RenameColumn(
                name: "UserInfoId",
                table: "Users",
                newName: "Id");
        }
    }
}
