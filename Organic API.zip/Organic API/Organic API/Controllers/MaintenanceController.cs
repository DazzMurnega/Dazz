﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Organic_API.Data;
using Organic_Farm_Web_API.Models;

namespace Organic_Farm_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MaintenanceController : ControllerBase
    {
        private readonly DataContext _farmContext;

        public MaintenanceController(DataContext context)
        {
            _farmContext = context;
        }

        //Methods for Maintenance Priority 
        [HttpPost]
        [Route("addMaintenancePriority")]
        public async Task<ActionResult<MaintenancePriority>> addMaintenancePriority(MaintenancePriority mp)
        {
            _farmContext.MaintenancePriorities.Add(mp);
            await _farmContext.SaveChangesAsync();
            return Ok("Maintenance priority has been added.");
        }

        [HttpGet]
        [Route("getMaintenancePriorities")]
        public async Task<ActionResult<MaintenancePriority>> getMaintenancePriorities()
        {
            if (_farmContext.MaintenancePriorities.Count() == 0)
            {
                return NotFound("No maintenance priorities have been added");
            }
            else
            {
                return Ok(await _farmContext.MaintenancePriorities.ToListAsync());
            }
        }

        [HttpGet("/getMaintenancePriority/{id}")]
        public async Task<ActionResult<MaintenancePriority>> getMaintenancePriorityById(int id)
        {
            var mp = await _farmContext.MaintenancePriorities.FindAsync(id);
            if (mp == null)
            {
                return NotFound("Maintenance priority " + id + " is not found.");
            }
            else
            {
                return Ok(mp);
            }
        }

        [HttpPut]
        [Route("updateMaintenancePriority")]
        public async Task<ActionResult<MaintenancePriority>> updateMaintenancePriority(MaintenancePriority mp)
        {
            _farmContext.MaintenancePriorities.Update(mp);
            await _farmContext.SaveChangesAsync();

            return Ok("Maintenance priority has been updated");
        }

        [HttpDelete("/deleteMaintenancePriority/{id}")]
        public async Task<ActionResult<MaintenancePriority>> deleteMaintenancePriority(int id)
        {
            var mp = _farmContext.MaintenancePriorities.Find(id);
            if (mp == null)
            {
                return NotFound("Maintenance priority " + id + " is not found");
            }
            else
            {
                _farmContext.MaintenancePriorities.Remove(mp);
                await _farmContext.SaveChangesAsync();

                return Ok("Maintenance priority has been removed");
            }
        }

        //Methods for Maintenance 
        [HttpPost]
        [Route("addMaintenance")]
        public async Task<ActionResult<Maintenance>> addMaintenance(Maintenance main)
        {
            _farmContext.Maintenances.Add(main);
            await _farmContext.SaveChangesAsync();
            return Ok("Maintenance has been added.");
        }

        [HttpGet]
        [Route("getMaintenances")]
        public async Task<ActionResult<Maintenance>> getMaintenances()
        {
            if (_farmContext.Maintenances.Count() == 0)
            {
                return NotFound("No maintenance has been added");
            }
            else
            {
                return Ok(await _farmContext.Maintenances.ToListAsync());
            }
        }

        [HttpGet("/getMaintenance/{id}")]
        public async Task<ActionResult<Maintenance>> getMaintenanceById(int id)
        {
            var main = await _farmContext.Maintenances.FindAsync(id);
            if (main == null)
            {
                return NotFound("Maintenance " + id + " is not found.");
            }
            else
            {
                return Ok(main);
            }
        }

        [HttpPut]
        [Route("updateMaintenance")]
        public async Task<ActionResult<Maintenance>> updateMaintenance(Maintenance main)
        {
            _farmContext.Maintenances.Update(main);
            await _farmContext.SaveChangesAsync();

            return Ok("Maintenance has been updated");
        }

        [HttpDelete("/deleteMaintenance/{id}")]
        public async Task<ActionResult<Maintenance>> deleteMaintenance(int id)
        {
            var main = _farmContext.Maintenances.Find(id);
            if (main == null)
            {
                return NotFound("Maintenance " + id + " is not found");
            }
            else
            {
                _farmContext.Maintenances.Remove(main);
                await _farmContext.SaveChangesAsync();

                return Ok("Maintenance has been removed");
            }
        }


        //Methods for Maintenance Solution
        [HttpPost]
        [Route("addMaintenanceSolution/{UserID}/{MaintenanceID}")]
        public async Task<ActionResult<MaintenanceSolution>> addMaintenanceSolution(MaintenanceSolution sol, int UserID, int MaintenanceID)
        {
            _farmContext.MaintenanceSolutions.Add(sol);
            await _farmContext.SaveChangesAsync();

            var maintenanceIssue = _farmContext.RecordMaintenanceIssues.Find(UserID, MaintenanceID);
            if (maintenanceIssue != null)
            {
                maintenanceIssue.MaintenanceSolutionId = sol.MaintenanceSolutionId;
                await _farmContext.SaveChangesAsync();
            }

            return Ok("Maintenance solution has been added.");
        }

        [HttpGet]
        [Route("getMaintenanceSolutions")]
        public async Task<ActionResult<MaintenanceSolution>> getMaintenanceSolutions()
        {
            if (_farmContext.MaintenanceSolutions.Count() == 0)
            {
                return NotFound("No maintenance solution has been added");
            }
            else
            {
                return Ok(await _farmContext.MaintenanceSolutions.ToListAsync());
            }
        }

        [HttpGet("/getMaintenanceSolution/{id}")]
        public async Task<ActionResult<MaintenanceSolution>> getMaintenanceSolutionById(int id)
        {
            var sol = await _farmContext.MaintenanceSolutions.FindAsync(id);
            if (sol == null)
            {
                return NotFound("Maintenance solution " + id + " is not found.");
            }
            else
            {
                return Ok(sol);
            }
        }

        [HttpPut]
        [Route("updateMaintenanceSolution")]
        public async Task<ActionResult<MaintenanceSolution>> updateMaintenanceSolution(MaintenanceSolution sol)
        {
            _farmContext.MaintenanceSolutions.Update(sol);
            await _farmContext.SaveChangesAsync();

            return Ok("Maintenance solution has been updated");
        }

        [HttpDelete("/deleteMaintenanceSolution/{UserID}/{MaintenanceID}/{SolutionId}")]
        public async Task<ActionResult<MaintenanceSolution>> deleteMaintenanceSolution(int UserId, int MaintenanceID, int SolutionId)
        {
            var sol = _farmContext.MaintenanceSolutions.Find(SolutionId);
            if (sol == null)
            {
                return NotFound("Maintenance solution " + SolutionId + " is not found");
            }
            else
            {
                Console.WriteLine("The user ID is: " + UserId);

                var maintenanceIssue = _farmContext.RecordMaintenanceIssues.Find(UserId, MaintenanceID);
                if (maintenanceIssue != null)
                {
                    maintenanceIssue.MaintenanceSolutionId = null;
                    await _farmContext.SaveChangesAsync();
                }

                _farmContext.MaintenanceSolutions.Remove(sol);
                await _farmContext.SaveChangesAsync();

                return Ok("Maintenance solution has been removed");
            }
        }

        //Methods for Maintenance Issue
        [HttpPost]
        [Route("addMaintenanceIssue")]
        public async Task<ActionResult<RecordMaintenanceIssue>> addMaintenanceIssue(RecordMaintenanceIssue issue)
        {
            _farmContext.RecordMaintenanceIssues.Add(issue);
            await _farmContext.SaveChangesAsync();
            return Ok("Maintenance issue has been added.");
        }

        [HttpGet]
        [Route("getMaintenanceIssues")]
        public async Task<ActionResult<RecordMaintenanceIssue>> getMaintenanceIssues()
        {
            if (_farmContext.RecordMaintenanceIssues.Count() == 0)
            {
                return NotFound("No maintenance issue has been added");
            }
            else
            {
                return Ok(await _farmContext.RecordMaintenanceIssues.ToListAsync());
            }
        }

        [HttpGet("/getMaintenanceIssue/{UserId}/{MaintenanceId}")]
        public async Task<ActionResult<RecordMaintenanceIssue>> getMaintenanceIssueById(int UserId, int MaintenanceId)
        {
            var issue = await _farmContext.RecordMaintenanceIssues.FindAsync(UserId, MaintenanceId);
            if (issue == null)
            {
                return NotFound("Maintenance issue (" + UserId + ", " + MaintenanceId + ") is not found.");
            }
            else
            {
                return Ok(issue);
            }
        }

        [HttpPut]
        [Route("updateMaintenanceIssue")]
        public async Task<ActionResult<RecordMaintenanceIssue>> updateMaintenanceIssue(RecordMaintenanceIssue issue)
        {
            _farmContext.RecordMaintenanceIssues.Update(issue);
            await _farmContext.SaveChangesAsync();

            return Ok("Maintenance issue has been updated");
        }

        [HttpDelete("/deleteMaintenanceIssue/{UserId}/{MaintenanceId}")]
        public async Task<ActionResult<RecordMaintenanceIssue>> deleteMaintenanceIssue(int UserId, int MaintenanceId)
        {
            var issue = _farmContext.RecordMaintenanceIssues.Find(UserId, MaintenanceId);
            if (issue == null)
            {
                return NotFound("Maintenance issue (" + UserId + ", " + MaintenanceId + " is not found");
            }
            else
            {
                _farmContext.RecordMaintenanceIssues.Remove(issue);
                await _farmContext.SaveChangesAsync();

                return Ok("Maintenance issue has been removed");
            }
        }
    }
}
