﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.EntityFrameworkCore;
using Organic_API.Data;
using Organic_API.Entities;

namespace Organic_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserInfoController : ControllerBase
    {

        private readonly DataContext _context;

        public UserInfoController(DataContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<ActionResult<List<UserInfo>>> GetUsers()
        {

            var users = await _context.Users.ToListAsync();
            return Ok(users);

        }

        [HttpGet("{username}")]

        public async Task<ActionResult<List<UserInfo>>> GetUser(UserInfo username)
        {

            var users = await _context.Users.FindAsync(username);
            if (User is null)
            {
                return NotFound("User not found");
            }
            return Ok(username);

        }


        [HttpPost]
        public async Task<ActionResult<List<UserInfo>>> AddUser(UserInfo user)
        {

            _context.Users.Add(user);
            await _context.SaveChangesAsync();

            return Ok(await _context.Users.ToListAsync());

        }

        [HttpPut]
        public async Task<ActionResult<UserInfo>> UpdateUser(UserInfo updateUser)
        {
            int userID = updateUser.UserInfoId;
            /*if(await _farmContext.UserTables.FindAsync(userID) == null)
            {
                return BadRequest("This user does not exist");
            }*/

            _context.Users.Update(updateUser);
            await _context.SaveChangesAsync();

            return CreatedAtAction("addUser", new { id = userID }, updateUser);

        }

        [HttpDelete]

        public async Task<ActionResult<List<UserInfo>>> DeleteUser(int id)
        {

            var dbuser = await _context.Users.FindAsync(id);
            if (dbuser is null)
            {
                return NotFound("User not found");
            }

            _context.Users.Remove(dbuser);

            await _context.SaveChangesAsync();

            return Ok(await _context.Users.ToListAsync());

        }


    }
}
