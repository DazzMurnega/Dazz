﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Organic_API.Data;
using Organic_Farm_Web_API.Models;

namespace Organic_Farm_Web_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CropController : ControllerBase
    {
        private readonly DataContext _farmContext;

        public CropController(DataContext context)
        {
            _farmContext = context;
        }

        //Methods for Crop type
        [HttpPost]
        [Route("addCropType")]
        public async Task<ActionResult<CropType>> addCropType(CropType ct)
        {
            _farmContext.CropTypes.Add(ct);
            await _farmContext.SaveChangesAsync();
            return Ok("Crop type has been added.");
        }

        [HttpGet]
        [Route("getCropTypes")]
        public async Task<ActionResult<CropType>> getCropTypes()
        {
            if (_farmContext.CropTypes.Count() == 0)
            {
                return NotFound("No crop type has been allocated");
            }
            else
            {
                return Ok(await _farmContext.CropTypes.ToListAsync());
            }
        }

        [HttpGet("/getCropType/{id}")]
        public async Task<ActionResult<CropType>> getCropTypeById(int id)
        {
            var ct = await _farmContext.CropTypes.FindAsync(id);
            if (ct == null)
            {
                return NotFound("Crop type " + id + " is not found.");
            }
            else
            {
                return Ok(ct);
            }
        }

        [HttpPut]
        [Route("updateCropType")]
        public async Task<ActionResult<CropType>> updateCropType(CropType ct)
        {
            _farmContext.CropTypes.Update(ct);
            await _farmContext.SaveChangesAsync();

            return Ok("Crop type has been updated");
        }

        [HttpDelete("/deleteCropType/{id}")]
        public async Task<ActionResult<CropType>> deleteCropType(int id)
        {
            var ct = _farmContext.CropTypes.Find(id);
            if (ct == null)
            {
                return NotFound("Crop type " + id + " is not found");
            }
            else
            {
                _farmContext.CropTypes.Remove(ct);
                await _farmContext.SaveChangesAsync();

                return Ok("Crop type has been removed");
            }
        }

        //Methods for Crop
        [HttpPost]
        [Route("addCrop")]
        public async Task<ActionResult<Crop>> addCrop(Crop crop)
        {
            _farmContext.Crops.Add(crop);
            await _farmContext.SaveChangesAsync();
            return Ok("Crop has been added.");
        }

        [HttpGet]
        [Route("getCrops")]
        public async Task<ActionResult<Crop>> getCrops()
        {
            if (_farmContext.Crops.Count() == 0)
            {
                return NotFound("No crop has been added");
            }
            else
            {
                return Ok(await _farmContext.Crops.ToListAsync());
            }
        }

        [HttpGet("/getCrop/{id}")]
        public async Task<ActionResult<Crop>> getCropById(int id)
        {
            var crop = await _farmContext.Crops.FindAsync(id);
            if (crop == null)
            {
                return NotFound("Crop " + id + " is not found.");
            }
            else
            {
                return Ok(crop);
            }
        }

        [HttpPut]
        [Route("updateCrop")]
        public async Task<ActionResult<Crop>> updateCrop(Crop crop)
        {
            _farmContext.Crops.Update(crop);
            await _farmContext.SaveChangesAsync();

            return Ok("Crop has been updated");
        }

        [HttpDelete("/deleteCrop/{id}")]
        public async Task<ActionResult<Crop>> deleteCrop(int id)
        {
            var crop = _farmContext.Crops.Find(id);
            if (crop == null)
            {
                return NotFound("Crop " + id + " is not found");
            }
            else
            {
                _farmContext.Crops.Remove(crop);
                await _farmContext.SaveChangesAsync();

                return Ok("Crop has been removed");
            }
        }

        //Methods for Harvest Season
        [HttpPost]
        [Route("addHarvestSeason")]
        public async Task<ActionResult<HarvestSeason>> addHarvestSeason(HarvestSeason hs)
        {
            _farmContext.HarvestSeasons.Add(hs);
            await _farmContext.SaveChangesAsync();
            return Ok("Harvest season has been added.");
        }

        [HttpGet]
        [Route("getHarvestSeasons")]
        public async Task<ActionResult<HarvestSeason>> getHarvestSeasons()
        {
            if (_farmContext.HarvestSeasons.Count() == 0)
            {
                return NotFound("No harvest season has been added");
            }
            else
            {
                return Ok(await _farmContext.HarvestSeasons.ToListAsync());
            }
        }

        [HttpGet("/getHarvestSeason/{id}")]
        public async Task<ActionResult<HarvestSeason>> getHarvestSeasonById(int id)
        {
            var hs = await _farmContext.HarvestSeasons.FindAsync(id);
            if (hs == null)
            {
                return NotFound("Harvest season " + id + " is not found.");
            }
            else
            {
                return Ok(hs);
            }
        }

        [HttpPut]
        [Route("updateHarvestSeason")]
        public async Task<ActionResult<HarvestSeason>> updateHarvestSeason(HarvestSeason hs)
        {
            _farmContext.HarvestSeasons.Update(hs);
            await _farmContext.SaveChangesAsync();

            return Ok("Harvest season has been updated");
        }

        [HttpDelete("/deleteHarvestSeason/{id}")]
        public async Task<ActionResult<HarvestSeason>> deleteHarvestSeason(int id)
        {
            var hs = _farmContext.HarvestSeasons.Find(id);
            if (hs == null)
            {
                return NotFound("Harvest season " + id + " is not found");
            }
            else
            {
                _farmContext.HarvestSeasons.Remove(hs);
                await _farmContext.SaveChangesAsync();

                return Ok("Harvest season has been removed");
            }
        }

        //Methods for Harvest Quality
        [HttpPost]
        [Route("addHarvestQuality")]
        public async Task<ActionResult<HarvestQuality>> addHarvestQuality(HarvestQuality hq)
        {
            _farmContext.HarvestQualities.Add(hq);
            await _farmContext.SaveChangesAsync();
            return Ok("Harvest quality has been added.");
        }

        [HttpGet]
        [Route("getHarvestQualities")]
        public async Task<ActionResult<HarvestQuality>> getHarvestQualitiess()
        {
            if (_farmContext.HarvestQualities.Count() == 0)
            {
                return NotFound("No harvest quality has been added");
            }
            else
            {
                return Ok(await _farmContext.HarvestQualities.ToListAsync());
            }
        }

        [HttpGet("/getHarvestQuality/{id}")]
        public async Task<ActionResult<HarvestQuality>> getHarvestQualityById(int id)
        {
            var hq = await _farmContext.HarvestQualities.FindAsync(id);
            if (hq == null)
            {
                return NotFound("Harvest quality " + id + " is not found.");
            }
            else
            {
                return Ok(hq);
            }
        }

        [HttpPut]
        [Route("updateHarvestQuality")]
        public async Task<ActionResult<HarvestQuality>> updateHarvestQuality(HarvestQuality hq)
        {
            _farmContext.HarvestQualities.Update(hq);
            await _farmContext.SaveChangesAsync();

            return Ok("Harvest quality has been updated");
        }

        [HttpDelete("/deleteHarvestQuality/{id}")]
        public async Task<ActionResult<HarvestQuality>> deleteHarvestQuality(int id)
        {
            var hq = _farmContext.HarvestQualities.Find(id);
            if (hq == null)
            {
                return NotFound("Harvest quality " + id + " is not found");
            }
            else
            {
                _farmContext.HarvestQualities.Remove(hq);
                await _farmContext.SaveChangesAsync();

                return Ok("Harvest quality has been removed");
            }
        }

        //Methods for Harvest Crop
        [HttpPost]
        [Route("addHarvestCrop/{CropId}/{TaskId}")]
        public async Task<ActionResult<HarvestCrop>> addHarvestCrop(HarvestCrop hc, int CropId, int TaskId)
        {
            _farmContext.HarvestCrops.Add(hc);
            await _farmContext.SaveChangesAsync();

            var cropRelatedTask = _farmContext.PerformCropRelatedTasks.Find(CropId, TaskId);
            if (cropRelatedTask != null)
            {
                cropRelatedTask.CropPlantationId = hc.HarvestCropId;
                await _farmContext.SaveChangesAsync();
            }

            return Ok("Harvest crop has been added.");
        }

        [HttpGet]
        [Route("getHarvestCrops")]
        public async Task<ActionResult<HarvestQuality>> getHarvestCrops()
        {
            if (_farmContext.HarvestCrops.Count() == 0)
            {
                return NotFound("No crop has been harvested");
            }
            else
            {
                return Ok(await _farmContext.HarvestQualities.ToListAsync());
            }
        }

        [HttpGet("/getHarvestCrop/{id}")]
        public async Task<ActionResult<HarvestCrop>> getHarvestCropById(int id)
        {
            var hc = await _farmContext.HarvestCrops.FindAsync(id);
            if (hc == null)
            {
                return NotFound("Harvest crop " + id + " is not found.");
            }
            else
            {
                return Ok(hc);
            }
        }

        [HttpPut]
        [Route("updateHarvestCrop")]
        public async Task<ActionResult<HarvestCrop>> updateHarvestCrop(HarvestCrop hc)
        {
            _farmContext.HarvestCrops.Update(hc);
            await _farmContext.SaveChangesAsync();

            return Ok("Harvest crop has been updated");
        }

        [HttpDelete("/deleteHarvestCrop/{CropId}/{TaskId}/{harvestCropId}")]
        public async Task<ActionResult<HarvestCrop>> deleteHarvestCrop(int CropId, int TaskId, int harvestCropId)
        {
            var hc = _farmContext.HarvestCrops.Find(harvestCropId);
            if (hc == null)
            {
                return NotFound("Harvest crop " + harvestCropId + " is not found");
            }
            else
            {
                var cropRelatedTask = _farmContext.PerformCropRelatedTasks.Find(CropId, TaskId);
                if (cropRelatedTask != null)
                {
                    cropRelatedTask.CropPlantationId = null;
                    await _farmContext.SaveChangesAsync();
                }

                _farmContext.HarvestCrops.Remove(hc);
                await _farmContext.SaveChangesAsync();

                return Ok("Harvest crop has been removed");
            }
        }

        //Methods for plant Crop
        [HttpPost]
        [Route("addPlantCrop/{CropId}/{TaskId}")]
        public async Task<ActionResult<PlantCrop>> addPlantCrop(PlantCrop pc, int CropId, int TaskId)
        {
            _farmContext.PlantCrops.Add(pc);
            await _farmContext.SaveChangesAsync();

            var cropRelatedTask = _farmContext.PerformCropRelatedTasks.Find(CropId, TaskId);
            if (cropRelatedTask != null)
            {
                cropRelatedTask.CropPlantationId = pc.PlantCropId;
                await _farmContext.SaveChangesAsync();
            }

            return Ok("Plant crop has been added.");
        }

        [HttpGet]
        [Route("getPlantCrops")]
        public async Task<ActionResult<PlantCrop>> getPlantCrops()
        {
            if (_farmContext.PlantCrops.Count() == 0)
            {
                return NotFound("No crop has been planted");
            }
            else
            {
                return Ok(await _farmContext.PlantCrops.ToListAsync());
            }
        }

        [HttpGet("/getPlantCrop/{id}")]
        public async Task<ActionResult<PlantCrop>> getPlantCropById(int id)
        {
            var pc = await _farmContext.PlantCrops.FindAsync(id);
            if (pc == null)
            {
                return NotFound("Plant crop " + id + " is not found.");
            }
            else
            {
                return Ok(pc);
            }
        }

        [HttpPut]
        [Route("updatePlantCrop")]
        public async Task<ActionResult<PlantCrop>> updatePlantCrop(PlantCrop pc)
        {
            _farmContext.PlantCrops.Update(pc);
            await _farmContext.SaveChangesAsync();

            return Ok("Plant crop has been updated");
        }

        [HttpDelete("/deletePlantCrop/{CropId}/{TaskId}/{plantCropId}")]
        public async Task<ActionResult<PlantCrop>> deletePlantCrop(int CropId, int TaskId, int plantCropId)
        {
            var pc = _farmContext.PlantCrops.Find(plantCropId);
            if (pc == null)
            {
                return NotFound("Plant crop " + plantCropId + " is not found");
            }
            else
            {
                var cropRelatedTask = _farmContext.PerformCropRelatedTasks.Find(CropId, TaskId);
                if (cropRelatedTask != null)
                {
                    cropRelatedTask.CropPlantationId = null;
                    await _farmContext.SaveChangesAsync();
                }

                _farmContext.PlantCrops.Remove(pc);
                await _farmContext.SaveChangesAsync();

                return Ok("Harvest crop has been removed");
            }
        }

        //Methods for perfrom plant related task
        [HttpPost]
        [Route("addCropRelatedTask")]
        public async Task<ActionResult<PerformCropRelatedTask>> addCropRelatedTask(PerformCropRelatedTask cropTask)
        {
            _farmContext.PerformCropRelatedTasks.Add(cropTask);
            await _farmContext.SaveChangesAsync();
            return Ok("Crop related task has been added.");
        }

        [HttpGet]
        [Route("getCropRelatedTasks")]
        public async Task<ActionResult<PerformCropRelatedTask>> getPerformCropRelatedTasks()
        {
            if (_farmContext.PlantCrops.Count() == 0)
            {
                return NotFound("No crop related tasks has been planted");
            }
            else
            {
                return Ok(await _farmContext.PerformCropRelatedTasks.ToListAsync());
            }
        }

        [HttpGet("/getCropRelatedTask/{CropId}/{TaskId}")]
        public async Task<ActionResult<PerformCropRelatedTask>> getCropRelatedTaskById(int CropId, int TaskId)
        {
            var cropTask = await _farmContext.PerformCropRelatedTasks.FindAsync(CropId, TaskId);
            if (cropTask == null)
            {
                return NotFound("Crop related task (" + CropId + ", " + TaskId + ") is not found.");
            }
            else
            {
                return Ok(cropTask);
            }
        }

        [HttpPut]
        [Route("updateCropRelatedTask")]
        public async Task<ActionResult<PerformCropRelatedTask>> updateCropRelatedTask(PerformCropRelatedTask cropTask)
        {
            _farmContext.PerformCropRelatedTasks.Update(cropTask);
            await _farmContext.SaveChangesAsync();

            return Ok("Crop related task has been updated");
        }

        [HttpDelete("/deleteCropRelatedTask/{CropId}/{TaskId}")]
        public async Task<ActionResult<PerformCropRelatedTask>> deleteCropRelatedTask(int CropId, int TaskId)
        {
            var cropTask = _farmContext.PerformCropRelatedTasks.Find(CropId, TaskId);
            if (cropTask == null)
            {
                return NotFound("Crop related task (" + CropId + ", " + TaskId + " is not found");
            }
            else
            {
                _farmContext.PerformCropRelatedTasks.Remove(cropTask);
                await _farmContext.SaveChangesAsync();

                return Ok("Crop related task has been removed");
            }
        }
    }
}
